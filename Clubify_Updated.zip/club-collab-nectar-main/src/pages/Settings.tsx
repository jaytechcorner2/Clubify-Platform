import React from "react";

const Settings = () => {
  return (
    <div style={{ padding: "20px" }}>
      <h1>Settings</h1>
      <p>This is the settings page. Configure your account preferences here.</p>
    </div>
  );
};

export default Settings;
